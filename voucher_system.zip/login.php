<?php
//pre need pages
include_once __DIR__.'/config/config.php';
include_once __DIR__.'/includes/processing.php';
include_once __DIR__.'/themes/default/head.php';


//working page
include_once __DIR__.'/themes/default/login.php';
?>







<?php

include_once __DIR__.'/themes/default/footer.php';

?>