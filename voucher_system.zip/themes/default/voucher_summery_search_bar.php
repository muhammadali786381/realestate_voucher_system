<!-- Begin Page Content -->
        <div class="container-fluid">
            
            
            <form action="" method="get">
            <div class="row">
                <div class="col-sm-3 mb-3 mb-sm-0">
                      <label>From</label>
                      <input type="date" name="from_date" class="form-control form-control-user" value="<?php echo (isset($_GET['from_date']))? $_GET['from_date']: "" ; ?>"  required="">
                  </div>
                   <div class="col-sm-3 mb-3 mb-sm-0">
                      <label>To</label>
                      <input type="date" name="to_date" class="form-control form-control-user" value="<?php echo (isset($_GET['to_date']))? $_GET['to_date']: "" ; ?>"  required="">
                  </div>
                 <div class="col-sm-2 mb-3 mb-sm-0">
                      <label>Funds Inflow & Outlflow</label>
                      <select class="form-control" name="method" required="">
                          <?php
                          if(isset($_GET['method'])){
                              echo "<option value='".$_GET['method']."'>".$_GET['method']."</option>";
                          }
                          
                          echo $view-> selectPaymentMethod();
                          ?>
                      </select>
                  </div>
                <div class="col-sm-2 mb-3 mb-sm-0">
                      <label>Summery Type</label>
                      <select class="form-control" name="summery_type" required="">
                           <?php
                          if(isset($_GET['summery_type'])){
                              echo "<option value='".$_GET['summery_type']."'>".$_GET['summery_type']."</option>";
                          }
                         ?>
                           <option value="">Select Type</option>
                          <option value="ShortSummery">Short Summery</option>
                          <option value="DetailSummery">Detail Summery</option>
                      </select>
                  </div> 
                  <div class="col-sm-2 mb-3 mb-sm-0">
                      <label></label>
                      <button type="submit" class="form-control btn btn-primary"  name="getSummery"><i class="fa fa-search"></i> Run Report</button>
                  </div>  
               </div>
        </form>
            
            
            
            
            
            
      </div>
        <!-- /.container-fluid -->
        